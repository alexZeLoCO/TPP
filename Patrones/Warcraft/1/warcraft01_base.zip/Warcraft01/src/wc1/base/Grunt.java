package wc1.base;

public class Grunt extends Unidad {

}
