package wc1.base;

public class Incursor extends Unidad {

}
