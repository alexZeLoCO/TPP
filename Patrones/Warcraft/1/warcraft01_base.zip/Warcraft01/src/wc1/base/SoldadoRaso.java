package wc1.base;

public class SoldadoRaso extends Unidad {

}
