package wc1.base;

public class Caballero extends Unidad {

}
