
public class Pikachu extends Pokemon {

}
